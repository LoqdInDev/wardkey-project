// WARDKEY Background Service Worker v2.0

// Restrict session storage to trusted contexts only (extension pages, NOT content scripts)
chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });

// ═══════ INSTALL & CONTEXT MENU ═══════
chrome.runtime.onInstalled.addListener((details) => {
  // Session storage already restricted to trusted contexts at top of file

  // Context menus
  chrome.contextMenus.create({
    id: 'wardkey-generate',
    title: '🔐 WARDKEY — Generate Password',
    contexts: ['editable']
  });
  chrome.contextMenus.create({
    id: 'wardkey-open',
    title: '🔐 WARDKEY — Open Vault',
    contexts: ['page', 'frame']
  });

  // Open welcome page on first install
  if (details.reason === 'install') {
    chrome.tabs.create({ url: 'https://wardkey.io?source=extension' });
  }
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'wardkey-generate') {
    // Only fill on http/https pages
    if (!tab.url || (!tab.url.startsWith('http:') && !tab.url.startsWith('https:'))) return;
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=';
    const limit = 256 - (256 % chars.length);
    let pw = '';
    while (pw.length < 20) {
      const arr = crypto.getRandomValues(new Uint8Array(36));
      for (const b of arr) {
        if (b < limit) pw += chars[b % chars.length];
        if (pw.length >= 20) break;
      }
    }
    const targetDomain = new URL(tab.url).hostname;
    chrome.tabs.sendMessage(tab.id, { type: 'WARDKEY_FILL_PW', password: pw, targetDomain }).catch(() => {});
  }
  if (info.menuItemId === 'wardkey-open') {
    chrome.action.openPopup();
  }
});

// ═══════ KEYBOARD SHORTCUTS ═══════
chrome.commands.onCommand.addListener((command) => {
  if (command === 'generate_password') {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return;
      // Only fill on http/https pages
      if (!tab.url || (!tab.url.startsWith('http:') && !tab.url.startsWith('https:'))) return;
      const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=';
      const limit = 256 - (256 % chars.length);
      let pw = '';
      while (pw.length < 20) {
        const arr = crypto.getRandomValues(new Uint8Array(36));
        for (const b of arr) {
          if (b < limit) pw += chars[b % chars.length];
          if (pw.length >= 20) break;
        }
      }
      const targetDomain = new URL(tab.url).hostname;
      chrome.tabs.sendMessage(tab.id, { type: 'WARDKEY_FILL_PW', password: pw, targetDomain }).catch(() => {});
    });
  }
});

// ═══════ BADGE ═══════
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab?.url) updateBadge(tab);
  } catch {}
});

async function updateBadge(tab) {
  try {
    const url = new URL(tab.url);
    if (url.protocol !== 'http:' && url.protocol !== 'https:') {
      chrome.action.setBadgeText({ text: '', tabId: tab.id });
      return;
    }
    chrome.action.setBadgeBackgroundColor({ color: '#3d7cf5' });
  } catch {
    chrome.action.setBadgeText({ text: '', tabId: tab.id });
  }
}

// ═══════ TAB NAVIGATION — PROMOTE CAPTURES TO PENDING SAVES ═══════
// When a tab navigates, check if the content script had captured credentials.
// If so, promote them from wardkey_capture to wardkey_pendingSave so the
// dialog shows on the new page.
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'loading' && tab?.url) {
    // Tab is navigating — check for captured credentials
    chrome.storage.session?.get('wardkey_capture', async (data) => {
      if (data?.wardkey_capture?.hasPassword) {
        const capture = data.wardkey_capture;
        // Only promote if recent (within 30 seconds)
        if (Date.now() - capture.timestamp < 30000) {
          // Check never-save list
          if (await isNeverSave(capture.domain)) {
            chrome.storage.session?.remove('wardkey_capture');
            return;
          }
          // Preserve username from existing pending or stored username capture (multi-step login)
          if (!capture.username) {
            const prev = await chrome.storage.session?.get('wardkey_pendingSave');
            if (prev?.wardkey_pendingSave?.username && prev.wardkey_pendingSave.domain === capture.domain) {
              capture.username = prev.wardkey_pendingSave.username;
            } else {
              const udata = await chrome.storage.session?.get('wardkey_username');
              if (udata?.wardkey_username?.domain === capture.domain && Date.now() - udata.wardkey_username.timestamp < 300000) {
                capture.username = udata.wardkey_username.username;
              }
            }
          }
          // Promote to pending save
          await chrome.storage.session?.set({ wardkey_pendingSave: capture });
          // Notify popup if open
          chrome.runtime.sendMessage({ type: 'WARDKEY_PENDING_SAVE' }).catch(() => {});
        }
        // Clear the capture
        chrome.storage.session?.remove('wardkey_capture');
      }
    });

    // Also update badge
    updateBadge(tab);
  }
  if (info.status === 'complete' && tab?.url) updateBadge(tab);
});

// ═══════ AUTO-LOCK TIMER ═══════
chrome.alarms.create('wardkey-autolock', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'wardkey-autolock') {
    chrome.storage.local.get('wardkey_lockTimeout', (settings) => {
      const timeout = settings.wardkey_lockTimeout ?? 0;
      if (timeout === 0) return;
      // For "browser session" mode, enforce a hard cap of 24 hours
      const effectiveTimeout = timeout === -1 ? 86400000 : timeout;
      chrome.storage.session?.get('wardkey_session', (data) => {
        if (data?.wardkey_session?.ts) {
          const elapsed = Date.now() - data.wardkey_session.ts;
          if (elapsed > effectiveTimeout) {
            chrome.storage.session?.remove('wardkey_session');
            chrome.storage.session?.remove('wardkey_credentials');
          }
        }
      });
    });
  }
  // Clear pending save password after 5 minutes to avoid lingering plaintext
  if (alarm.name === 'wardkey-clear-pending-pw') {
    chrome.storage.session?.get('wardkey_pendingSave', (data) => {
      if (data?.wardkey_pendingSave?.password) {
        const updated = { ...data.wardkey_pendingSave };
        delete updated.password;
        chrome.storage.session?.set({ wardkey_pendingSave: updated });
      }
    });
  }
});

// ═══════ NEVER-SAVE LIST ═══════
async function isNeverSave(domain) {
  const data = await chrome.storage.local.get('wardkey_neverSave');
  const list = data.wardkey_neverSave || [];
  return list.includes(domain);
}

// ═══════ MESSAGE HANDLER ═══════
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Validate sender: only accept from own extension or http/https content scripts
  if (sender.id !== chrome.runtime.id) return;
  if (sender.tab && sender.tab.url) {
    const protocol = new URL(sender.tab.url).protocol;
    if (protocol !== 'http:' && protocol !== 'https:') return;
  }

  if (msg.type === 'WARDKEY_OPEN_POPUP') {
    chrome.action.openPopup();
  }

  if (msg.type === 'WARDKEY_ACTIVITY') {
    chrome.storage.session?.set({ wardkey_lastActive: Date.now() });
  }

  if (msg.type === 'WARDKEY_BADGE') {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (tab) {
        const text = msg.count > 0 ? String(msg.count) : '';
        chrome.action.setBadgeText({ text, tabId: tab.id });
      }
    });
  }

  // Username-only capture for multi-step logins (email on page 1, password on page 2)
  if (msg.type === 'WARDKEY_STORE_USERNAME') {
    if (typeof msg.domain !== 'string' || !msg.domain) return;
    if (typeof msg.username !== 'string' || !msg.username) return;
    if (typeof msg.url !== 'string') return;
    try { new URL(msg.url); } catch { return; }
    const senderHost = new URL(sender.tab.url).hostname.replace(/^www\./, '');
    if (msg.domain !== senderHost) return;
    chrome.storage.session?.set({ wardkey_username: { domain: msg.domain, username: msg.username, timestamp: msg.timestamp } });
  }

  // Content script credential capture (via message passing, not direct session storage)
  if (msg.type === 'WARDKEY_STORE_CAPTURE') {
    // Validate required fields and types
    if (typeof msg.domain !== 'string' || !msg.domain) return;
    if (typeof msg.username !== 'string') return;
    if (typeof msg.hasPassword !== 'boolean' || !msg.hasPassword) return;
    if (typeof msg.url !== 'string') return;
    try { new URL(msg.url); } catch { return; }
    if (typeof msg.timestamp !== 'number') return;

    // Verify msg.domain matches the actual sender tab's hostname
    const senderHost = new URL(sender.tab.url).hostname.replace(/^www\./, '');
    if (msg.domain && msg.domain !== senderHost) return;

    (async () => {
      // Merge username from earlier username-only capture (multi-step login)
      let username = msg.username;
      if (!username) {
        const stored = await chrome.storage.session?.get('wardkey_username');
        if (stored?.wardkey_username?.domain === msg.domain && Date.now() - stored.wardkey_username.timestamp < 300000) {
          username = stored.wardkey_username.username;
        }
      }

      // Store credential detection — include password only when captured at form submit
      const captureData = {
        domain: msg.domain,
        username,
        hasPassword: true,
        url: msg.url,
        timestamp: msg.timestamp
      };
      if (typeof msg.password === 'string' && msg.password) {
        captureData.password = msg.password;
        chrome.alarms.create('wardkey-clear-pending-pw', { delayInMinutes: 5 });
      }
      chrome.storage.session?.set({ wardkey_capture: captureData });
    })();
  }

  // Content script requests credentials for current site (inline dropdown)
  // SECURITY: Only returns id/name/username — NO passwords sent to content scripts
  if (msg.type === 'WARDKEY_GET_SITE_CREDENTIALS') {
    if (typeof msg.domain !== 'string' || !msg.domain) return;
    // Verify domain matches sender tab
    if (sender.tab?.url) {
      const senderHost = new URL(sender.tab.url).hostname.replace(/^www\./, '');
      if (msg.domain !== senderHost) return;
    }
    chrome.storage.session?.get('wardkey_credentials', (data) => {
      const creds = data?.wardkey_credentials || [];
      // Exact domain match only (no subdomain matching for inline dropdown)
      const matches = creds.filter(c => c.domain && c.domain === msg.domain)
        .map(c => ({ id: c.id, name: c.name, username: c.username }));
      sendResponse({ credentials: matches });
    });
    return true; // async sendResponse
  }

  // Content script requests autofill by credential ID (dropdown item selected)
  // Background resolves password from popup's vault and sends WARDKEY_FILL to the tab
  if (msg.type === 'WARDKEY_FILL_BY_ID') {
    if (typeof msg.id !== 'string' || !msg.id) return;
    if (!sender.tab?.id || !sender.tab?.url) return;
    const senderHost = new URL(sender.tab.url).hostname.replace(/^www\./, '');
    // Forward to popup to resolve the password (popup has the decrypted vault)
    chrome.runtime.sendMessage({ type: 'WARDKEY_RESOLVE_FILL', id: msg.id, tabId: sender.tab.id, domain: senderHost }).catch(() => {
      // Popup not open — notify user
      chrome.tabs.sendMessage(sender.tab.id, { type: 'WARDKEY_FILL_FAILED', reason: 'Vault is locked. Open WARDKEY first.' }).catch(() => {});
    });
  }

  // Content script checks for pending save dialog
  if (msg.type === 'WARDKEY_CHECK_PENDING') {
    chrome.storage.session?.get('wardkey_pendingSave', (data) => {
      sendResponse({ pending: data?.wardkey_pendingSave || null });
    });
    return true; // async sendResponse
  }

  // Content script dismisses pending save
  if (msg.type === 'WARDKEY_DISMISS_PENDING') {
    chrome.storage.session?.remove('wardkey_pendingSave');
  }

  // Legacy: content script form submit detection (backup path)
  if (msg.type === 'WARDKEY_SAVE_PROMPT') {
    if (typeof msg.domain !== 'string' || !msg.domain) return;
    if (typeof msg.username !== 'string') return;
    if (typeof msg.url !== 'string') return;
    try { new URL(msg.url); } catch { return; }

    // Verify msg.domain matches the actual sender tab's hostname
    const senderHost = new URL(sender.tab.url).hostname.replace(/^www\./, '');
    if (msg.domain && msg.domain !== senderHost) return;

    (async () => {
      if (await isNeverSave(msg.domain)) return;
      await chrome.storage.session?.set({
        wardkey_pendingSave: {
          domain: msg.domain,
          username: msg.username,
          hasPassword: true,
          url: msg.url,
          timestamp: Date.now()
        }
      });
      chrome.runtime.sendMessage({ type: 'WARDKEY_PENDING_SAVE' }).catch(() => {});
    })();
  }

  // User clicked "Save" in content script dialog
  if (msg.type === 'WARDKEY_SAVE_CONFIRM') {
    if (typeof msg.domain !== 'string' || !msg.domain) return;
    if (typeof msg.username !== 'string') return;
    if (typeof msg.url !== 'string') return;
    try { new URL(msg.url); } catch { return; }

    (async () => {
      // Allow if domain matches sender OR matches existing pending save (post-redirect)
      const senderHost = new URL(sender.tab.url).hostname.replace(/^www\./, '');
      if (msg.domain !== senderHost) {
        const existing = await chrome.storage.session.get('wardkey_pendingSave');
        if (!existing?.wardkey_pendingSave || existing.wardkey_pendingSave.domain !== msg.domain) return;
      }

      const existing = await chrome.storage.session.get('wardkey_pendingSave');
      const prev = existing?.wardkey_pendingSave;

      // Resolve username: current msg > previous pending > stored username capture
      let resolvedUsername = msg.username;
      if (!resolvedUsername && prev?.username && prev.domain === msg.domain) {
        resolvedUsername = prev.username;
      }
      if (!resolvedUsername) {
        const udata = await chrome.storage.session.get('wardkey_username');
        if (udata?.wardkey_username?.domain === msg.domain && Date.now() - udata.wardkey_username.timestamp < 300000) {
          resolvedUsername = udata.wardkey_username.username;
        }
      }

      const saveData = {
        domain: msg.domain,
        username: resolvedUsername || '',
        hasPassword: true,
        url: msg.url,
        timestamp: Date.now(),
        confirmed: true
      };
      // Store password if captured at click time (before page navigates)
      if (typeof msg.password === 'string' && msg.password) {
        saveData.password = msg.password;
        chrome.alarms.create('wardkey-clear-pending-pw', { delayInMinutes: 5 });
      } else if (prev?.password) {
        // Preserve password from earlier capture phase (form submit)
        saveData.password = prev.password;
      }
      await chrome.storage.session.set({ wardkey_pendingSave: saveData });
      chrome.runtime.sendMessage({ type: 'WARDKEY_PENDING_SAVE' }).catch(() => {});
    })();
  }

  // User clicked "Never" for a domain
  if (msg.type === 'WARDKEY_SAVE_NEVER') {
    if (typeof msg.domain !== 'string' || !msg.domain || msg.domain.length > 255) return;
    if (!/^[a-zA-Z0-9.-]+$/.test(msg.domain)) return;
    (async () => {
      const data = await chrome.storage.local.get('wardkey_neverSave');
      const list = data.wardkey_neverSave || [];
      if (list.length >= 500) return;
      if (!list.includes(msg.domain)) {
        list.push(msg.domain);
        await chrome.storage.local.set({ wardkey_neverSave: list });
      }
      await chrome.storage.session?.remove('wardkey_pendingSave');
    })();
  }

  return true;
});
